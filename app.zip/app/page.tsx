import FlyerEditor from "@/components/FlyerEditor";

export default function Home() {
  return (
    <main style={{ minHeight: "100vh", background: "#f0f2f5" }}>
      <div style={{
        padding: "20px 0",
        background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
        color: "white",
        textAlign: "center",
        marginBottom: 20,
      }}>
        <h1 style={{ fontSize: "2.5em", margin: "10px 0" }}>
          🎨 AI MITRA Flyer Editor
        </h1>
        <p style={{ fontSize: "1.1em", opacity: 0.95 }}>
          Create beautiful event flyers with AI • Multi-language support • WhatsApp ready
        </p>
      </div>
      <FlyerEditor/>
      
      <footer style={{
        textAlign: "center",
        padding: "40px 20px",
        color: "#666",
        fontSize: "0.9em",
      }}>
        <p>Built with ❤️ by AI MITRA • Powered by OpenAI DALL-E & Fabric.js</p>
      </footer>
    </main>
  );
}
